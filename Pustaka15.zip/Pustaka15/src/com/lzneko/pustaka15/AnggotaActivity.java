package com.lzneko.pustaka15;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.view.View;
import android.widget.*;
import android.os.*;
import android.graphics.*;
import android.app.ActionBar.LayoutParams;
import android.content.Intent;

@SuppressLint("InlinedApi") public class AnggotaActivity extends Activity {
	
	BukuActivity bukuActivity = new BukuActivity();
    TableLayout tableLayout;
    JSONArray arrayAdmin;

    @SuppressLint("NewApi") @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_anggota);

        ActionBar actionBar = getActionBar();
        actionBar.hide();
        
		// Jika SDK Android diatas API Ver.9
		        if (android.os.Build.VERSION.SDK_INT > 9) {
		            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
		                    .permitAll().build();
		            StrictMode.setThreadPolicy(policy);
		        }
		// Mendapatkan data widget dari XML Activity melalui ID
		        tableLayout = (TableLayout) findViewById(R.id.tableAnggota);
		//menambah baris untuk tabel
		        TableRow barisTabel = new TableRow(this);
		        barisTabel.setBackgroundColor(Color.GRAY);
		        
		// Menambahkan tampilan teks untuk judul pada tabel
		        TextView viewHeaderId = new TextView(this);
		        TextView viewHeaderNama = new TextView(this);
		        TextView viewHeaderAlamat = new TextView(this);
		        TextView viewHeaderEmail = new TextView(this);
		        TextView viewHeaderImage = new TextView(this);
		        TextView viewHeaderIsactive = new TextView(this);
		        
		        viewHeaderId.setText("ID");
		        viewHeaderNama.setText("Nama");
		        viewHeaderAlamat.setText("Alamat");
		        viewHeaderEmail.setText("Email");
		        viewHeaderImage.setText("Image");
		        viewHeaderIsactive.setText("is_active");
		        
		        viewHeaderId.setPadding(5, 1, 5, 1);
		        viewHeaderNama.setPadding(5, 1, 5, 1);
		        viewHeaderAlamat.setPadding(5, 1, 5, 1);
		        viewHeaderEmail.setPadding(5, 1, 5, 1);
		        viewHeaderImage.setPadding(5, 1, 5, 1);
		        viewHeaderIsactive.setPadding(5, 1, 5, 1);
		        
		// Menampilkan tampilan TextView ke dalam tabel
		        barisTabel.addView(viewHeaderId);
		        barisTabel.addView(viewHeaderNama);
		        barisTabel.addView(viewHeaderAlamat);
		        barisTabel.addView(viewHeaderEmail);
		        barisTabel.addView(viewHeaderImage);
		        barisTabel.addView(viewHeaderIsactive);
		        
		// Menyusun ukuran dari tabel
		        tableLayout.addView(barisTabel, new
		                TableLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
		        try {
		// Mengubah data dari BukuActivity yang berupa String menjadi array
		            arrayAdmin = new JSONArray(bukuActivity.tampilAnggota());
		            for (int i = 0; i < arrayAdmin.length(); i++) {
		                JSONObject jsonChildNode = arrayAdmin.getJSONObject(i);
		                String is_active = jsonChildNode.optString("is_active");
		                String image = jsonChildNode.optString("image");
		                String email = jsonChildNode.optString("email");
		                String alamat = jsonChildNode.optString("alamat");
		                String nama = jsonChildNode.optString("nama");
		                String id = jsonChildNode.optString("id");
		                System.out.println("Ststus Aktif : " + is_active );
		                System.out.println("Gambar : " + image );
		                System.out.println("Email : " + email );
		                System.out.println("Alamat : " + alamat );
		                System.out.println("Nama : " + nama );
		                System.out.println("ID : " + id);
		                barisTabel = new TableRow(this);
		// Memberi warna pada baris tabel
		                if (i % 2 == 0) {
		                    barisTabel.setBackgroundColor(Color.LTGRAY);
		                }
		                TextView viewId = new TextView(this);
		                viewId.setText(id);
		                viewId.setPadding(5, 1, 5, 1);
		                barisTabel.addView(viewId);
		                TextView viewNama = new TextView(this);
		                viewNama.setText(nama);
		                viewNama.setPadding(5, 1, 5, 1);
		                barisTabel.addView(viewNama);
		                
		                TextView viewAlamat = new TextView(this);
		                viewAlamat.setText(alamat);
		                viewAlamat.setPadding(5, 1, 5, 1);
		                barisTabel.addView(viewAlamat);
		                TextView viewEmail = new TextView(this);
		                viewEmail.setText(email);
		                viewEmail.setPadding(5, 1, 5, 1);
		                barisTabel.addView(viewEmail);
		                
		                TextView viewImage = new TextView(this);
		                viewImage.setText(image);
		                viewImage.setPadding(5, 1, 5, 1);
		                barisTabel.addView(viewImage);
		                TextView viewIsActive = new TextView(this);
		                viewIsActive.setText(is_active);
		                viewIsActive.setPadding(5, 1, 5, 1);
		                barisTabel.addView(viewIsActive);
		                
		                tableLayout.addView(barisTabel, new TableLayout.LayoutParams
		                        (LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
		            }
		        }
		        catch (JSONException e) {
		            e.printStackTrace();
		        } 
    }
    public void keActMenu(View view){
    	Intent intent = new Intent (this, MainActivity.class);
    	startActivity(intent);
    }
    
    public void keActAdmin(View view){
    	Intent intent = new Intent (this, AdminActivity.class);
    	startActivity(intent);
    }

    
}
