package com.lzneko.pustaka15;
public class BukuActivity extends KoneksiActivity {
	// sourcecode untuk URL -> URL menggunakan IP address default eclipse
//		urlnya pastikan sama dengan lokasi file php kalian ya
		String URL = "http://10.0.2.2/PustakaApp/crud.php";
		String url = "";
		String response = "";
		//menampilkan Buku dari database
		
		public String tampilBuku() {
			try{
				url = URL + "?operasi=viewbuku";
				System.out.println("URL Tampil Buku : " + url);
				response = call(url);
			}
			catch(Exception e) {
			}
			return response;
		}

		public String tampilAdmin() {
			try{
				url = URL + "?operasi=viewadmin";
				System.out.println("URL Tampil Admin : " + url);
				response = call(url);
			}
			catch(Exception e) {
			}
			return response;
		}

		public String tampilAnggota() {
			try{
				url = URL + "?operasi=viewanggota";
				System.out.println("URL Tampil Anggota : " + url);
				response = call(url);
			}
			catch(Exception e) {
			}
			return response;
		}
		//memasukan Buku baru ke dalam database
		public String insertBuku(String judul_buku, String id_kategori, String pengarang
				, String penerbit, String tahun_terbit, String isbn, String stok, String image) {
			try{
				url = URL + "?operasi=insert&judul_buku=" + judul_buku
						+ "&id_kategori=" + id_kategori + "&pengarang=" + pengarang
						+ "&penerbit=" + penerbit + "&tahun_terbit=" + tahun_terbit
						+ "&isbn=" + isbn + "&stok=" + stok + "&image=" + image;
				System.out.println("URL Insert Buku : " + url);
				response = call(url);
			}
			catch (Exception e){
			}
			return response;
		}
		//melihat Buku berdasarkan ID
		public String getBukuById (int id) {
			try{
				url=URL + "?operasi=get_Buku_by_id&id=" + id;
				System.out.println("URL Insert Buku : " + url);
				response = call(url);
			}
			catch(Exception e) {
			}
			return response;
		}
		//mengubah isi Buku
		public String updateBuku(String id, String judul_buku, String id_kategori, String pengarang
				, String penerbit, String tahun_terbit, String isbn, String stok, String image) {
			try{
				url=URL + "?operasi=update&id=" + id + "&judul_buku=" + judul_buku
						+ "&id_kategori=" + id_kategori + "&pengarang=" + pengarang
						+ "&penerbit=" + penerbit + "&tahun_terbit=" + tahun_terbit
						+ "&isbn=" + isbn + "&stok=" + stok + "&image=" + image;
				System.out.println("URL Update Buku : " + url);
				response = call(url);
			}
			catch(Exception e){
			}
			return response;
		}
		//coding hapus
		public String deleteBuku (int id) {
			try{
				url = URL + "?operasi=delete&id=" + id;
				System.out.println("URL Hapus Buku : " + url);
				response = call(url);
			}
			catch(Exception e){
			}
			return response;
		}
	}