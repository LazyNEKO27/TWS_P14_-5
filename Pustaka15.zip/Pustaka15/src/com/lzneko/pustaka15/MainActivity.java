package com.lzneko.pustaka15;

import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.*;
import android.os.*;
import android.graphics.*;
import android.app.ActionBar.LayoutParams;
import android.content.DialogInterface;
import android.content.Intent;

@SuppressLint("InlinedApi") public class MainActivity extends Activity implements OnClickListener {
    BukuActivity bukuActivity = new BukuActivity();
//    TableLayout tableLayoutAdmin;
    TableLayout tableLayout;
    Button buttonTambahBuku;
    
    ArrayList<Button>buttonEdit = new ArrayList<Button>();
    ArrayList<Button>buttonDelete = new ArrayList<Button>();
//    JSONArray ArrayAdmin;
    JSONArray arrayBuku;
    @SuppressLint("NewApi") @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        ActionBar actionBar = getActionBar();
        actionBar.hide();
        
// Jika SDK Android diatas API Ver.9
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                    .permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
// Mendapatkan data widget dari XML Activity melalui ID
        tableLayout = (TableLayout) findViewById(R.id.tableBuku);
        buttonTambahBuku = (Button) findViewById(R.id.buttonTambahBuku);
        buttonTambahBuku.setOnClickListener(this);
//menambah baris untuk tabel
        TableRow barisTabel = new TableRow(this);
        barisTabel.setBackgroundColor(Color.GRAY);
// Menambahkan tampilan teks untuk judul pada tabel
        TextView viewHeaderId = new TextView(this);
        TextView viewHeaderJudul = new TextView(this);
        TextView viewHeaderKtg = new TextView(this);
        TextView viewHeaderPengarang = new TextView(this);
        TextView viewHeaderPenerbit = new TextView(this);
        TextView viewHeaderThn_Ter = new TextView(this);
        TextView viewHeaderISBN = new TextView(this);
        TextView viewHeaderStok = new TextView(this);
        TextView viewHeaderImage = new TextView(this);
        TextView viewHeaderAksi = new TextView(this);
        
        viewHeaderId.setText("ID");
        viewHeaderJudul.setText("Judul Buku");
        viewHeaderKtg.setText("Kategori");
        viewHeaderPengarang.setText("Pengarang");
        viewHeaderPenerbit.setText("Penerbit");
        viewHeaderThn_Ter.setText("Tahun Terbit");
        viewHeaderISBN.setText("ISBN");
        viewHeaderStok.setText("Stok");
        viewHeaderImage.setText("Image");
        viewHeaderAksi.setText("Aksi");
        
        viewHeaderId.setPadding(5, 1, 5, 1);
        viewHeaderJudul.setPadding(5, 1, 5, 1);
        viewHeaderKtg.setPadding(5, 1, 5, 1);
        viewHeaderPengarang.setPadding(5, 1, 5, 1);
        viewHeaderPenerbit.setPadding(5, 1, 5, 1);
        viewHeaderThn_Ter.setPadding(5, 1, 5, 1);
        viewHeaderISBN.setPadding(5, 1, 5, 1);
        viewHeaderStok.setPadding(5, 1, 5, 1);
        viewHeaderImage.setPadding(5, 1, 5, 1);
        viewHeaderAksi.setPadding(5, 1, 5, 1);
        
// Menampilkan tampilan TextView ke dalam tabel
        barisTabel.addView(viewHeaderId);
        barisTabel.addView(viewHeaderJudul);
        barisTabel.addView(viewHeaderKtg);
        barisTabel.addView(viewHeaderPengarang);
        barisTabel.addView(viewHeaderPenerbit);
        barisTabel.addView(viewHeaderThn_Ter);
        barisTabel.addView(viewHeaderISBN);
        barisTabel.addView(viewHeaderStok);
        barisTabel.addView(viewHeaderImage);
        barisTabel.addView(viewHeaderAksi);
// Menyusun ukuran dari tabel
        tableLayout.addView(barisTabel, new
                TableLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        try {
// Mengubah data dari BukuActivity yang berupa String menjadi array
            arrayBuku = new JSONArray(bukuActivity.tampilBuku());
            for (int i = 0; i < arrayBuku.length(); i++) {
                JSONObject jsonChildNode = arrayBuku.getJSONObject(i);
                String image = jsonChildNode.optString("image");
                String stok = jsonChildNode.optString("stok");
                String isbn = jsonChildNode.optString("isbn");
                String tahun_terbit = jsonChildNode.optString("tahun_terbit");
                String penerbit = jsonChildNode.optString("penerbit");
                String pengarang = jsonChildNode.optString("pengarang");
                String kategori = jsonChildNode.optString("kategori");
                String judul_buku = jsonChildNode.optString("judul_buku");
                String id = jsonChildNode.optString("id");
                System.out.println("Gambar : " + image );
                System.out.println("Stok : " + stok );
                System.out.println("ISBN : " + isbn );
                System.out.println("Thn Terbit : " + tahun_terbit );
                System.out.println("Penerbit : " + penerbit );
                System.out.println("Pengarang : " + pengarang );
                System.out.println("Kategori : " + kategori );
                System.out.println("Judul : " + judul_buku );
                System.out.println("ID : " + id);
                barisTabel = new TableRow(this);
// Memberi warna pada baris tabel
                if (i % 2 == 0) {
                    barisTabel.setBackgroundColor(Color.LTGRAY);
                }
                TextView viewId = new TextView(this);
                viewId.setText(id);
                viewId.setPadding(5, 1, 5, 1);
                barisTabel.addView(viewId);
                TextView viewJudul = new TextView(this);
                viewJudul.setText(judul_buku);
                viewJudul.setPadding(5, 1, 5, 1);
                barisTabel.addView(viewJudul);
                TextView viewKtg = new TextView(this);
                viewKtg.setText(kategori);
                viewKtg.setPadding(5, 1, 5, 1);
                barisTabel.addView(viewKtg);
                TextView viewPengarang = new TextView(this);
                viewPengarang.setText(pengarang);
                viewPengarang.setPadding(5, 1, 5, 1);
                barisTabel.addView(viewPengarang);
                TextView viewPenerbit = new TextView(this);
                viewPenerbit.setText(penerbit);
                viewPenerbit.setPadding(5, 1, 5, 1);
                barisTabel.addView(viewPenerbit);
                TextView viewThnTerbit = new TextView(this);
                viewThnTerbit.setText(tahun_terbit);
                viewThnTerbit.setPadding(5, 1, 5, 1);
                barisTabel.addView(viewThnTerbit);
                TextView viewISBN = new TextView(this);
                viewISBN.setText(isbn);
                viewISBN.setPadding(5, 1, 5, 1);
                barisTabel.addView(viewISBN);
                TextView viewStok = new TextView(this);
                viewStok.setText(stok);
                viewStok.setPadding(5, 1, 5, 1);
                barisTabel.addView(viewStok);
                TextView viewImage = new TextView(this);
                viewImage.setText(image);
                viewImage.setPadding(5, 1, 5, 1);
                barisTabel.addView(viewImage);
// Menambahkan button Edit
                buttonEdit.add(i, new Button(this));
                buttonEdit.get(i).setId(Integer.parseInt(id));
                buttonEdit.get(i).setTag("Edit");
                buttonEdit.get(i).setText("Edit");
                buttonEdit.get(i).setOnClickListener(this);
                barisTabel.addView(buttonEdit.get(i));
// Menambahkan tombol Delete
                buttonDelete.add(i, new Button(this));
                buttonDelete.get(i).setId(Integer.parseInt(id));
                buttonDelete.get(i).setTag("Delete");
                buttonDelete.get(i).setText("Delete");
                buttonDelete.get(i).setOnClickListener(this);
                barisTabel.addView(buttonDelete.get(i));
                tableLayout.addView(barisTabel, new TableLayout.LayoutParams
                        (LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
            }
        }
        catch (JSONException e) {
            e.printStackTrace();
        } 

    }
    
    public void keActAdmin(View view){
    	Intent intent = new Intent (this, AdminActivity.class);
    	startActivity(intent);
    	
    }

    public void keActAnggota(View view){
    	Intent intent = new Intent (this, AnggotaActivity.class);
    	startActivity(intent);
    }
    
    public void onClick (View view) {
        if (view.getId() == R.id.buttonTambahBuku) {
            tambahBuku();
        }
        else {
            for (int i= 0; i < buttonEdit.size(); i++) {
// Jika ingin mengedit data pada Buku
                if (view.getId() == buttonEdit.get(i).getId() &&
                        view.getTag().toString().trim().equals("Edit")) {
                    Toast.makeText(MainActivity.this, "Edit : " + buttonEdit.get(i).getId(),
                            Toast.LENGTH_SHORT).show();
                    int id = buttonEdit.get(i).getId();
                    getDataByID(id);
                }
// Menghapus data di Tabel
                else if (view.getId() == buttonDelete.get(i).getId() &&
                        view.getTag().toString().trim().equals("Delete")){
                    Toast.makeText(MainActivity.this, "Delete : " +
                            buttonDelete.get(i).getId(), Toast.LENGTH_SHORT).show();
                    int id = buttonDelete.get(i).getId();
                    deleteBuku(id);
                }
            }
        }
    }
    public void deleteBuku (int id) {
        bukuActivity.deleteBuku(id);
        finish();
        startActivity(getIntent());
    }
    // Mendapatkan Buku melalui ID
    public void getDataByID (int id) {
        String editJudul = null, editKategori = null, editPengarang = null, editPenerbit = null,
        		editThn_terbit = null, editISBN = null, editStok = null, editGambar = null;
        JSONArray arrayPersonal;
        try {
            arrayPersonal = new JSONArray(bukuActivity.getBukuById(id));
            for (int i = 0; i < arrayPersonal.length(); i++) {
                JSONObject jsonChildNode = arrayPersonal.getJSONObject(i);
                editJudul = jsonChildNode.optString("judul");
                editKategori = jsonChildNode.optString("kategori");
                editPengarang = jsonChildNode.optString("pengarang");
                editPenerbit = jsonChildNode.optString("penerbit");
                editThn_terbit = jsonChildNode.optString("Tahun Terbit");
                editISBN = jsonChildNode.optString("ISBN");
                editStok = jsonChildNode.optString("Stok");
                editGambar = jsonChildNode.optString("Gambar");
            }
        }
        catch (JSONException e) {
            e.printStackTrace();
        }
        LinearLayout layoutInput = new LinearLayout(this);
        layoutInput.setOrientation(LinearLayout.VERTICAL);
// Membuat id tersembunyi pada AlertDialog
        final TextView viewId = new TextView(this);
        viewId.setText(String.valueOf(id));
        viewId.setTextColor(Color.TRANSPARENT);
        layoutInput.addView(viewId);
		 
	 final EditText EditJudul = new EditText(this);
	 	 EditJudul.setText(editJudul);
		 layoutInput.addView(EditJudul);

	 final EditText EditKategori = new EditText(this);
	 	 EditKategori.setText(editKategori);
		 layoutInput.addView(EditKategori);
		 
	 final EditText EditPengarang = new EditText(this);
	 	 EditPengarang.setText(editPengarang);
		 layoutInput.addView(EditPengarang);

	 final EditText EditPenerbit = new EditText(this);
	 	 EditPenerbit.setText(editPenerbit);
		 layoutInput.addView(EditPenerbit);

	 final EditText EditThn_terbit = new EditText(this);
	 	 EditThn_terbit.setText(editThn_terbit);
		 layoutInput.addView(EditThn_terbit);

	 final EditText EditISBN = new EditText(this);
	 	 EditISBN.setText(editISBN);
		 layoutInput.addView(EditISBN);

	 final EditText EditStok = new EditText(this);
	 	 EditStok.setText(editStok);
		 layoutInput.addView(EditStok);

	 final EditText EditGambar = new EditText(this);
	     EditGambar.setText(editGambar);
		 layoutInput.addView(EditGambar);
		 
// Membuat AlertDialog untuk mengubah data di Buku
        AlertDialog.Builder builderEditBuku = new AlertDialog.Builder(this);
        
//builderEditBuku.setIcon(R.drawable.webse);
        builderEditBuku.setTitle("Update Buku");
        builderEditBuku.setView(layoutInput);
        builderEditBuku.setPositiveButton("Update", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String judul_buku = EditJudul.getText().toString();
                String id_kategori = EditKategori.getText().toString();
                String pengarang = EditPengarang.getText().toString();
                String penerbit = EditPenerbit.getText().toString();
                String tahun_terbit = EditThn_terbit.getText().toString();
                String isbn = EditISBN.getText().toString();
                String stok = EditStok.getText().toString();
                String image = EditGambar.getText().toString();
    			System.out.println("Judul : " + judul_buku + "Kategori : " + id_kategori + "Pengarang : " + pengarang
    					 + "Penerbit : " + penerbit + "Tahun Terbit : " + tahun_terbit + "ISBN : " + isbn
    					 + "Stok : " + stok + "Image : " + image);
                String laporan = bukuActivity.updateBuku(viewId.getText().toString(),
                		EditJudul.getText().toString(),
                		EditKategori.getText().toString(),
                		EditPengarang.getText().toString(),
                		EditPenerbit.getText().toString(),
                		EditThn_terbit.getText().toString(),
                		EditISBN.getText().toString(),
                		EditStok.getText().toString(),
                		EditGambar.getText().toString());
                Toast.makeText(MainActivity.this, laporan, Toast.LENGTH_SHORT).show();
                finish();
                startActivity(getIntent());
            }
        });
// Jika tidak ingin mengubah data pada Buku
        builderEditBuku.setNegativeButton("Cancel", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builderEditBuku.show();
    }
    public void tambahBuku() {
        LinearLayout layoutInput = new LinearLayout(this);
        layoutInput.setOrientation(LinearLayout.VERTICAL);

   	 final EditText EditJudul = new EditText(this);
   	 	 EditJudul.setHint("Judul");
   		 layoutInput.addView(EditJudul);

   	 final EditText EditKategori = new EditText(this);
   	 	 EditKategori.setHint("Kategori");
   		 layoutInput.addView(EditKategori);
   		 
   	 final EditText EditPengarang = new EditText(this);
   	 	 EditPengarang.setHint("Pengarang");
   		 layoutInput.addView(EditPengarang);

   	 final EditText EditPenerbit = new EditText(this);
   	 	 EditPenerbit.setHint("Penerbit");
   		 layoutInput.addView(EditPenerbit);

	 final EditText EditThn_terbit = new EditText(this);
	 EditThn_terbit.setHint("Tahun Terbit");
		 layoutInput.addView(EditThn_terbit);

   	 final EditText EditISBN = new EditText(this);
   	 	 EditISBN.setHint("ISBN");
   		 layoutInput.addView(EditISBN);

	 final EditText EditStok = new EditText(this);
	 	 EditStok.setHint("Stok");
		 layoutInput.addView(EditStok);

   	 final EditText EditGambar = new EditText(this);
   	 	 EditGambar.setHint("Gambar");
   		 layoutInput.addView(EditGambar);
// Membuat AlertDialog untuk menambahkan data pada Buku
        AlertDialog.Builder builderinsertBuku= new AlertDialog.Builder(this);
//builderinsertBuku.setIcon(R.drawable.webse);
        builderinsertBuku.setTitle("Insert Buku");
        builderinsertBuku.setView(layoutInput);
        builderinsertBuku.setPositiveButton("Insert", new
                DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String judul_buku = EditJudul.getText().toString();
                        String id_kategori = EditKategori.getText().toString();
                        String pengarang = EditPengarang.getText().toString();
                        String penerbit = EditPenerbit.getText().toString();
                        String tahun_terbit = EditThn_terbit.getText().toString();
                        String isbn = EditISBN.getText().toString();
                        String stok = EditStok.getText().toString();
                        String image = EditGambar.getText().toString();
                        System.out.println("Judul : " + judul_buku + "Kategori : " + id_kategori + "Pengarang : " + pengarang
           					 + "Penerbit : " + penerbit + "Tahun Terbit : " + tahun_terbit + "ISBN : " + isbn
        					 + "Stok : " + stok + "Image : " + image);
                        String laporan = bukuActivity.insertBuku(judul_buku,id_kategori,pengarang,
                        		penerbit,tahun_terbit,isbn,stok,image);
                        Toast.makeText(MainActivity.this, laporan, Toast.LENGTH_SHORT).show();
                        finish();
                        startActivity(getIntent());
                    }
                });
        builderinsertBuku.setNegativeButton("Cancel", new
                DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
        builderinsertBuku.show();
    }
}