<?php

require_once 'database.php';

@$operasi = $_GET['operasi'];

switch ($operasi) {

    case "viewbuku":
        $query_tampil_buku = mysqli_query($conn, "SELECT buku.id,judul_buku,kategori,pengarang,penerbit,tahun_terbit,isbn,stok,image FROM buku JOIN kategori ON buku.id_kategori=kategori.id ") or die(mysqli_error($conn));
        $data_array = array();

        while ($data = mysqli_fetch_assoc($query_tampil_buku)) {
            $data_array[] = $data;
        }
        echo json_encode($data_array);

        break;

    case "viewadmin":
        $query_tampil_admin = mysqli_query($conn, "SELECT id,nama,alamat,email,image,is_active FROM user WHERE role_id=1") or die(mysqli_error($conn));
        $data_array = array();

        while ($data = mysqli_fetch_assoc($query_tampil_admin)) {
            $data_array[] = $data;
        }
        echo json_encode($data_array);

        break;

    case "viewanggota":
        $query_tampil_anggota = mysqli_query($conn, "SELECT id,nama,alamat,email,image,is_active FROM user WHERE role_id=2") or die(mysqli_error($conn));
        $data_array = array();

        while ($data = mysqli_fetch_assoc($query_tampil_anggota)) {
            $data_array[] = $data;
        }
        echo json_encode($data_array);

        break;

    default:
        break;
}
