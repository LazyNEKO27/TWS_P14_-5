<?php

define('host', 'localhost');
define('db_name', 'pustaka');
define('username', 'root');
define('password', '');

$conn = mysqli_connect(host, username, password, db_name)
    or die("<h1>Koneksi Mysqli Error : </h1>" . mysqli_connect_error());
